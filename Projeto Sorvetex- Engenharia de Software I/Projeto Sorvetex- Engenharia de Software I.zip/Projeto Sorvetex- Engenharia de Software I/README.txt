IDE: Apache Netbeans IDE 19

LP: Java(TM) SE Development Kit 21

Diagramas: Astah Community 7.2