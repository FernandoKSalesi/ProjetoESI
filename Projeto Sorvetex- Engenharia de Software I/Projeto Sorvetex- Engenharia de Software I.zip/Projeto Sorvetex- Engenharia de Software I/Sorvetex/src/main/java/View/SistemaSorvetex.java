/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package View;

/**
 *
 * @author Fernando
 */
public class SistemaSorvetex {

    public static void main(String[] args) {
        //interface
    }
}
